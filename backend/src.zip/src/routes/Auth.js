const authRoutes = require("./routes/auth");
app.use("/auth", authRoutes);
